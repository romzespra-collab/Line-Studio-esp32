"""Общие модули окна LineStudio."""
